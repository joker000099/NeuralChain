# Whitepaper + Vision Docs

To be added:
- Lightpaper
- Full technical whitepaper
- Pitch deck for grants/funding
