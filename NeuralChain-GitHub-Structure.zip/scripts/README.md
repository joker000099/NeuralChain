# Scripts – Devnet, Testnet, Utilities

This folder will include:
- `deploy-devnet.sh` → Local testnet deploy
- `reset-chain.sh` → Reset node data
- `faucet.js` → Dev faucet for token airdrops
