# Client – Light Interfaces

This will include:

- Command-line tool for node operators
- Mobile light node (Flutter/React Native)
- REST API and gRPC client
- Block explorer frontend (if separate)
