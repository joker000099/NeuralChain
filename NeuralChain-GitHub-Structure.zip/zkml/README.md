# zkML – Verifiable Machine Learning for NeuralChain

This folder will host:

- zkML proof circuits (EZKL, RISC Zero, etc.)
- Model compression + compilation pipelines
- Smart contract verifiers for model outputs
- Sample models (sentiment analysis, classifiers)
