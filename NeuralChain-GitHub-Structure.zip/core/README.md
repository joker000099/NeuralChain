# Core – NeuralChain

This folder will contain the core blockchain components:

- Consensus logic (HotStuff PoS)
- Staking + Validator module
- EVM engine integration (via Ethermint or parallel EVM)
- Message bus (tx mempool, block propagation)
