# Documentation

This folder includes:

- Architecture specs
- Consensus mechanism
- zkVM + zkML design flow
- Mobile light node design
